(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(public)_login_page_tsx_fe354d30._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(public)_login_page_tsx_fe354d30._.js",
  "chunks": [
    "static/chunks/_c2e5597b._.js"
  ],
  "source": "dynamic"
});
