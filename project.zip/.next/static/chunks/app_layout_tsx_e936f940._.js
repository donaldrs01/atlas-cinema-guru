(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_e936f940._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_e936f940._.js",
  "chunks": [
    "static/chunks/styles_global_859405b5.css",
    "static/chunks/node_modules_next_dist_2067ba8c._.js",
    "static/chunks/node_modules_react-icons_fa6_index_mjs_00e856c4._.js",
    "static/chunks/node_modules_react-icons_io5_index_mjs_39106f7b._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
    "static/chunks/node_modules_42fe55af._.js",
    "static/chunks/_e8101663._.js"
  ],
  "source": "dynamic"
});
