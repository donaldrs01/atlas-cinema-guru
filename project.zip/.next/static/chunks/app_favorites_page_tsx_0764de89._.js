(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_favorites_page_tsx_0764de89._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_favorites_page_tsx_0764de89._.js",
  "chunks": [
    "static/chunks/node_modules_next_15251bc2._.js",
    "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7f5._.js",
    "static/chunks/_bc5d9926._.js"
  ],
  "source": "dynamic"
});
