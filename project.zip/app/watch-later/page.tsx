"use client";

import useWatchLater from "@/hooks/useWatchLater";
import MovieGrid from "@/components/MovieGrid";
import PaginationControls from "@/components/PaginationControls";

export default function WatchLaterPage() {
  const { watchLater, currentPage, setCurrentPage, hasMore, toggleWatchLater } = useWatchLater();

  return (
    <main className="p-6 flex flex-col items-center">
      <h1 className="text-5-xl text-white font-bold mb-4">Watch Later</h1>
      <MovieGrid movies={watchLater} toggleWatchLater={toggleWatchLater} />
      <PaginationControls
        currentPage={currentPage}
        hasMore={hasMore}
        onPageChange={setCurrentPage}
      />
    </main>
  );
}