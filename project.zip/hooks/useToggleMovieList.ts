// Custom functions to handle both favorite and watchLater toggling
import { UsersTitle } from "@/lib/definitions";

export default function useToggleMovieList(
  movies: UsersTitle[],
  setMovies: (movies: UsersTitle[]) => void,
  listType: keyof Pick<UsersTitle, "favorited" | "watchLater">
) {
  async function toggleMovie(movieId: string) {
    try {
      // Check if the movie is already in list (either favorite or watch later)
      const movieIndex = movies.findIndex((movie) => movie.id === movieId);
      const isListed = movieIndex !== -1 && movies[movieIndex][listType];

      // Send request to backend
      const response = await fetch(`/api/${listType}/${movieId}`, {
        method: isListed ? "DELETE" : "POST", // Choose HTTP method based on whether favorited or not
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || `Failed to toggle ${listType}`);

      console.log(data.message);

      // update UI
      setMovies((prevMovies: UsersTitle[]) => {
        const movieExists = prevMovies.some((movie) => movie.id === movieId);

        if (isListed) {
          // If the movie is being removed, filter it out
          return prevMovies.filter((movie) => movie.id !== movieId);
        } else {
          // If the movie is being added, add it to the list
          return movieExists
              ? prevMovies.map((movie) =>
              movie.id === movieId? { ...movie, [listType]: true } : movie
            )
            : [...prevMovies, { id: movieId, title: "Unknown", image: "", favorited: false, watchLater: false, [listType]: true } as UsersTitle];
          }
      });
    } catch (error) {
      console.error(`Error toggling ${listType}`, error);
    }
  }

  return { toggleMovie };
}
