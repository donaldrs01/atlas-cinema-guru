import { useState, useEffect } from "react";
import { UsersTitle } from "@/lib/definitions";
import useToggleMovieList from "@/hooks/useToggleMovieList";

export default function useWatchLater() {
  const [watchLater, setWatchLater] = useState<UsersTitle[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const moviesPerPage = 6;

  const { toggleMovie: toggleWatchLater } = useToggleMovieList(watchLater, setWatchLater, "watchLater");

  // Fetch watch later movies from API
  useEffect(() => {
    async function fetchWatchLater() {
      try {
        const response = await fetch(`/api/watchLater?page=${currentPage}`);
        const data = await response.json();

        setWatchLater(data.watchLater || []);
        setHasMore(data.watchLater.length === moviesPerPage);
      } catch (error) {
        console.error("Error fetching watch later movies:", error);
      }
    }
    fetchWatchLater();
  }, [currentPage]);

  async function removeWatchLater(movieId: string) {
    // Update UI and remove movie from state immediately
    const updatedWatchLater = watchLater.filter((movie) => movie.id !== movieId);
    setWatchLater(updatedWatchLater);

    try {
      // Send request to backend
      const response = await fetch(`/api/watchLater/${movieId}`, { method: "DELETE" });
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to remove from Watch Later");
      }
      console.log(data.message);
    } catch (error) {
      console.error("Error removing from Watch Later:", error);
      setWatchLater((prevWatchLater) => [...prevWatchLater, watchLater.find((movie) => movie.id === movieId)!]);
    }
  }

  return {
    watchLater,
    setWatchLater,
    currentPage,
    setCurrentPage,
    hasMore,
    toggleWatchLater: removeWatchLater,
  };
}
